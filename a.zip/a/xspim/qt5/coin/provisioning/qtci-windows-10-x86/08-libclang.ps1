. "$PSScriptRoot\..\common\windows\libclang.ps1" 32 vs2015
