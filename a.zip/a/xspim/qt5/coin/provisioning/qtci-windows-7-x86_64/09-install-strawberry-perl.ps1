. "$PSScriptRoot\..\common\windows\install-strawberry-perl.ps1"
