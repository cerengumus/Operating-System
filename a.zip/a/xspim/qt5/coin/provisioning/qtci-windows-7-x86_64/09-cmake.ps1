. "$PSScriptRoot\..\common\windows\cmake.ps1"
