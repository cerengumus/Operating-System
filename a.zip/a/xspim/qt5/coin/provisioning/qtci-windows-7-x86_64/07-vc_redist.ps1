. "$PSScriptRoot\..\common\windows\vc_redist.ps1"
