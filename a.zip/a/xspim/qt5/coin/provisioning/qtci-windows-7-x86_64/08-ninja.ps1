. "$PSScriptRoot\..\common\windows\ninja.ps1"
