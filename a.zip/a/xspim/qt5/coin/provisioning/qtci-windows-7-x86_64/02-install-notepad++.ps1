. "$PSScriptRoot\..\common\windows\install-notepad++.ps1"
