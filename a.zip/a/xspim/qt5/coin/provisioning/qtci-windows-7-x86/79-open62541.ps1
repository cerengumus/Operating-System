. "$PSScriptRoot\..\common\windows\open62541.ps1" -targetCommand prepare
. "$PSScriptRoot\..\common\windows\open62541.ps1" -targetCommand mingw730
