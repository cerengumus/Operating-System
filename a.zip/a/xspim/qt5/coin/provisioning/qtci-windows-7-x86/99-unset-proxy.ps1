. "$PSScriptRoot\..\common\windows\unset-proxy.ps1"
