. "$PSScriptRoot\..\common\windows\set-proxy.ps1"
