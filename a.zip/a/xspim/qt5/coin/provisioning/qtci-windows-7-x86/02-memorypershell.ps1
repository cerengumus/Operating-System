. "$PSScriptRoot\..\common\windows\memorypershell.ps1"
