. "$PSScriptRoot\..\common\windows\python.ps1" 32 "C:\Python27_32"
