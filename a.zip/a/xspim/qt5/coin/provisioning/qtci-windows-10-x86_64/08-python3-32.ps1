. "$PSScriptRoot\..\common\windows\python3.ps1" 32 "C:\Python36_32"
