#!/usr/bin/env bash
set -ex

source "${BASH_SOURCE%/*}/../common/macos/python2.sh"
