#!/usr/bin/env bash
$(dirname "$0")/../common/macos/disable_spotlight.sh
