#!/usr/bin/env bash

$(dirname $0)/../common/unix/disable-ntp_macos.sh
