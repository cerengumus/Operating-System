. "$PSScriptRoot\..\common\windows\disable-sleep.ps1"
