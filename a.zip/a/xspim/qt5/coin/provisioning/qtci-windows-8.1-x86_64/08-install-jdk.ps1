. "$PSScriptRoot\..\common\windows\install-jdk.ps1"
