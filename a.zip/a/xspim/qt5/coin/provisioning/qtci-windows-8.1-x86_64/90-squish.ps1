. "$PSScriptRoot\..\common\windows\squishInstall.ps1"
