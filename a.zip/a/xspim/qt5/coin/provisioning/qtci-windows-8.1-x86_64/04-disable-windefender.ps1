. "$PSScriptRoot\..\common\windows\disable-windefender.ps1"
