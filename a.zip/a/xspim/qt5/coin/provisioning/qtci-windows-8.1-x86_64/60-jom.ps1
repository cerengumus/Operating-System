. "$PSScriptRoot\..\common\windows\jom.ps1"
