. "$PSScriptRoot\..\common\windows\set-network-test-server.ps1"
