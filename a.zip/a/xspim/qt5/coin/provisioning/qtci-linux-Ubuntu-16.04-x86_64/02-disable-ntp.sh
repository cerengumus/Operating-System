#!/usr/bin/env bash

source "${BASH_SOURCE%/*}/../common/linux/disable-ntp_linux.sh"
