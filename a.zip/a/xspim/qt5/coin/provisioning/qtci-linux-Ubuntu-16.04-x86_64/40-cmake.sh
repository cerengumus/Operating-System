#!/bin/bash

BASEDIR=$(dirname "$0")
$BASEDIR/../common/linux/cmake_linux.sh

