#define SPIM_VERSION "Version 9.1.21 of January 17, 2020"
